#!/bin/bash

./startServerMockup.sh -f ../../java/com/master/btrace/server/HelloWorld.java
