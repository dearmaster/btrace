#!/bin/bash

. ~/.profile

btrace 9620 ../../java/com/master/btrace/script/TraceEclipseGc.java
