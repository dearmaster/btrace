#!/bin/bash

#when there is another btrace script running in the backend, exception will be thrown saying 'Port 2020 unavailable'
#In this case, need to specify another port to running the current script since the default port 2020 is being using
./startTrace.sh -p 28682 -m HelloWorld -s ../../java/com/master/btrace/script/TraceThread.java
