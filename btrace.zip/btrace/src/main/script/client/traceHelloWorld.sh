#!/bin/bash


./startTrace.sh -p 23232 -m HelloWorld -s ../../java/com/master/btrace/script/TraceArgAndReturn.java
