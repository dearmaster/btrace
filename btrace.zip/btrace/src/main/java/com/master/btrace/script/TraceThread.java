package com.master.btrace.script;

import static com.sun.btrace.BTraceUtils.*;

import com.sun.btrace.AnyType;
import com.sun.btrace.annotations.BTrace;
import com.sun.btrace.annotations.OnMethod;
import com.sun.btrace.annotations.Self;

@BTrace public class TraceThread {
	
	/**
	 * 
	 * @param thread AnyType can be replaced by Object. While, as explained in AnyType.java user may want
	 * 		  to match Object parameter exactly in some cases, thus it will be better to use AnyType here.
	 */
	@OnMethod(
			clazz = "java.lang.Thread",
			method = "start"
	)
	public static void traceThreadCreation(@Self AnyType thread) {
		String threadName = str(get(field("java.lang.Thread","name"),thread));
		println(strcat("abount to start thread: ", threadName)); //the result is not as expected since the name is char[] type, something like C@4aa298b7
	}

}