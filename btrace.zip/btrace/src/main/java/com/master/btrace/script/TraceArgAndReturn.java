package com.master.btrace.script;

import com.sun.btrace.AnyType;
import com.sun.btrace.annotations.*;
import static com.sun.btrace.BTraceUtils.*;

import java.lang.reflect.Field;

@BTrace public class TraceArgAndReturn {

    @OnMethod(
            clazz = "com.master.btrace.server.HelloWorld",
            method = "execute",
            location = @Location(Kind.RETURN)
    )
    //public static void traceHelloWorldExecute(@Self Object self, int sleepTime, @Return boolean result) {
    public static void traceHelloWorldExecute(@Self AnyType self, int sleepTime, @Return boolean result) {
        println("call HelloWorld.execute");
        println(strcat("sleepTime is:",str(sleepTime)));
        println(strcat("sleepTotalTime is:",str(get(field("com.master.btrace.server.HelloWorld","sleepTotal"),self))));
        
        //the static fileds can't be traced, so, below will output null
        println(strcat("instance is:",str(get(field("com.master.btrace.server.HelloWorld","instance"),self))));
        
        //below will output something like com.master.btrace.server.HelloWorld$Employee@172985
        println(strcat("employee is:",str(get(field("com.master.btrace.server.HelloWorld","employee"),self))));
        
        //print the object fields
        Field portField = field(classForName("com.master.btrace.server.HelloWorld$Employee", contextClassLoader()), "name");
        Object employee = get(field("com.master.btrace.server.HelloWorld","employee"),self);
        println(strcat("Employee.name: ", (String) get(portField, employee)));
        
        //print the return value
        println(strcat("return value is:",str(result)));
    }
    
    @OnMethod(
            clazz = "com.master.btrace.server.HelloWorld",
            method = "mockReturnObject",
            location = @Location(Kind.RETURN)
    )
    //public static void traceHelloWorldMockReturnObject(@Return Object ret) {
    public static void traceHelloWorldMockReturnObject(@Return AnyType ret) {
    	println();
    	println();
    	println(strcat("The object returned is: ", str(ret)));
    	
        Field fieldId = field(classForName("com.master.btrace.server.HelloWorld$Employee", contextClassLoader()), "id");
        Field fieldName = field(classForName("com.master.btrace.server.HelloWorld$Employee", contextClassLoader()), "name");
        Field fieldBalance = field(classForName("com.master.btrace.server.HelloWorld$Employee", contextClassLoader()), "balance");
        println(strcat("id: ", str(get(fieldId, ret))));
        println(strcat("name: ", (String) get(fieldName, ret)));
        println(strcat("balance: ", str(get(fieldBalance, ret))));
    }
    
    @OnMethod(
            clazz = "com.master.btrace.server.HelloWorld",
            method = "mockProcessDuration",
            location = @Location(Kind.RETURN)
    )
    public static void traceHelloWorldMockProcessDuration(@ProbeClassName String pcn, @Duration long duration) {
    	println(strcat(pcn, strcat(strcat(" took ", str(duration/1000000000)), " seconds")));
    }

}
