package com.master.btrace.server;

public class HelloWorld {

    private static HelloWorld instance;

    private int sleepTotal = 0;
    private Employee employee; //doesn't need a getter or setter for this field

    private HelloWorld() {}

    public static HelloWorld getInstance() {
        if(null == instance) {
            synchronized(HelloWorld.class) {
                if(null == instance) {
                    instance = new HelloWorld();
                }
            }
        }
        return instance;
    }

    public static void main(String[] args) {
        HelloWorld demo = new HelloWorld();
        demo.employee = demo.new Employee(2, "Dear", 5.5);
        
        for(int i=0; i<10; i++) {
            demo.execute(2);
        }
        
        demo.mockReturnObject();
        
        long duration = 0;
        
        duration -= System.currentTimeMillis();
        demo.mockProcessDuration();
        duration += System.currentTimeMillis();
        System.out.println("mockProcessDuration took " + duration / 1000 + " seconds");
        
        demo.mockThreadCreation();
    }

    /**
     * To demo the trace of argument and return value
     * @param interval
     * @return
     */
    public boolean execute(int interval) {
        System.out.println("Sleep " + interval + " seconds....");
        try {
            Thread.sleep(interval * 1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        sleepTotal += interval;
        return true;
    }
    
    public Employee mockReturnObject() {
    	return new Employee(5, "lily", 100.5);
    }
    
    public void mockProcessDuration() {
    	for(int i=0; i<200; i++) {
    		try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
    	}
    }
    
    public void mockThreadCreation() {
    	for(int i=0; i<10; i++) {
    		new Thread() {
				@Override
				public void run() {
					System.out.println("Thread[" + this.getName() + "] is running");
					try {
						sleep(20);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
    		}.start();
    	}
    }
    
    /*
     * Though the BTrace uses reflect to get the fields.
     * It has no impact even if the pojo don't has a default constructor or getter and setter for the fields.
     * Not yet figured out why. 
     */
    class Employee {
    	
    	private int id;
    	private String name;
    	private Double balance;
    	
    	//public Employee() {}
    	
		public Employee(int id, String name, Double balance) {
			super();
			this.id = id;
			this.name = name;
			this.balance = balance;
		}
/*		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public Double getBalance() {
			return balance;
		}
		public void setBalance(Double balance) {
			this.balance = balance;
		}*/
    	
    }


}