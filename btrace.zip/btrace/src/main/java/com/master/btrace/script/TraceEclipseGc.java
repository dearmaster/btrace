package com.master.btrace.script;

import com.sun.btrace.annotations.BTrace;
import com.sun.btrace.annotations.OnMethod;

import static com.sun.btrace.BTraceUtils.*;

/**
 * 
 * Seems not work
 *
 */
@BTrace public class TraceEclipseGc {
	
	@OnMethod(
			clazz = "java.lang.System",
			method = "gc"
	)
	public static void onSystemGc() {
		println("entered System.gc()");
		jstack();
	}

}
